package com.cg.banking.service;

import com.cg.banking.bean.*;
import com.cg.banking.exceptions.AccountMismatchException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientBalanceException;

public interface BankingService {

	void  createAccount(Account account);

	void deposit(double amount, Integer accno) throws AccountNotFoundException;

	void withDraw(double amount, Integer accno) throws AccountNotFoundException, InsufficientBalanceException;

	void fundTransfer(Integer accno1, Integer accno2) throws AccountNotFoundException, InsufficientBalanceException, AccountMismatchException;

	//void showBalance(Integer accno) throws AccountNotFoundException;

	//void printTransactions(Integer accNo) throws AccountNotFoundException;
	
}
