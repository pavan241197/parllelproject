package com.cg.banking.service;

public class Transaction {
	private Integer transId;
	private String type;
	private String description;
	private double amount;

	public Transaction() {
		super();
	}

	public Transaction(String type, String description, double amount) {
		super();
		this.setType(type);
		this.setDescription(description);
		this.setAmount(amount);
	}

	public Integer getTransId() {
		return transId;
	}

	public void setTrans_Id(Integer trans_Id) {
		this.transId = transId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Transaction [transId=" + transId + ", type=" + type + ", description=" + description + ", amount="
				+ amount + "]";
	}

}
