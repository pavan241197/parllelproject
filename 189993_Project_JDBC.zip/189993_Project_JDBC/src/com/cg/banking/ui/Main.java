package com.cg.banking.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.banking.bean.Account;
import com.cg.banking.bean.Customer;
import com.cg.banking.dao.DaoImpl;
import com.cg.banking.exceptions.AccountMismatchException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientBalanceException;
import com.cg.banking.exceptions.NullStatementException;
import com.cg.banking.service.BankingServiceImpl;

public class Main extends Throwable {
	static Scanner scan = new Scanner(System.in);

	private static String input(String string) {
		String message = string;
		System.out.println(message);
		return scan.nextLine();
	}

	private static Account createCustomer() {
		Account account = new Account();
		Customer customer = new Customer();
		customer = new Customer();
		scan.nextLine();
		customer.setName(input("enter name"));
		customer.setPhoneNo(input("enter phone number"));
		customer.setDoorno(input("enter door no"));
		customer.setPincode(input("enter pincode"));
		account.setAccType(input("enter type of account"));
		customer.setCity(input("enter city"));
		account.setCustomer(customer);

		return account;
	}

	public static void main(String[] args) {
		BankingServiceImpl impl = new BankingServiceImpl();
		DaoImpl daoImpl = new DaoImpl();
		String choice = null;
		do {
			System.out.println("welcome to Paypa Bank");
			System.out.println("1 :Create Account");
			System.out.println("2 :Deposit");
			System.out.println("3 :Funds Transfer");
			System.out.println("4 :Withdraw");
			System.out.println("5: Delete");
			System.out.println("6 :Query");
			System.out.println("Enter Choice: ");
			choice = scan.next();
			// scan.nextLine();

			switch (choice) {
			case "1":
				impl.createAccount(createCustomer());
				System.out.println("Account created Successfully");
				break;
			case "2":
				try {
					System.out.println("enter amount to be deposit,enter account no");
					impl.deposit(scan.nextDouble(), scan.nextInt());

				} catch (AccountNotFoundException e) {
					System.err.println(e.getMessage());
				} catch (NumberFormatException e) {
					System.err.println("Invalid Input");
				} catch (InputMismatchException e) {
					System.err.println("Input not matched");
				}
				scan.nextLine();
				break;

			case "3":

				try {
					System.out.println("Enter sender accno and Receiver accNo");
					impl.fundTransfer(scan.nextInt(), scan.nextInt());

				} catch (InsufficientBalanceException e1) {

				} catch (AccountMismatchException e) {

				} catch (NumberFormatException e) {
					System.err.println("Invalid Input");
				} catch (InputMismatchException e) {
					System.err.println("Input not matched");
				}

				break;
			case "4":
				try {
					System.out.println("Enter amount and account no to with draw");

					double amount = 0;
					Integer accno = null;
					amount = scan.nextDouble();
					accno = scan.nextInt();
					impl.withDraw(amount, accno);

				} catch (InsufficientBalanceException e) {

				} catch (AccountNotFoundException e) {

				} catch (NumberFormatException e) {
					System.err.println("Invalid Input");
				} catch (InputMismatchException e) {
					System.err.println("Input not matched");
				}

				break;

			case "5":
				Integer accno = scan.nextInt();
				try {

					daoImpl.delete(accno);
					throw new AccountNotFoundException(accno, "Account not found");
				} catch (AccountNotFoundException e) {
				}
				break;
			case "6":

				daoImpl.query();

				break;

			default:
				System.err.println("invalid choice");
			}

		} while (choice.length() != 0);
	}

}
