package com.cg.banking.dao;

import java.sql.Date;
import com.cg.banking.bean.Account;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.service.Transaction;

public interface Dao {
	public void insert(Account account);

	public void update(double balance, Integer accno);

	public void delete(Integer accno) throws AccountNotFoundException;

	public void addTrans(Transaction transaction, Integer accno, Date date);

	public void query();

}
