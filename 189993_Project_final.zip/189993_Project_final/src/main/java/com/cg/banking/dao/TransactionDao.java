package com.cg.banking.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.banking.beans.Transaction;

@Repository
public interface TransactionDao extends JpaRepository<Transaction, Integer>{

	@Query("from Transaction where ACCOUNT_ACCNO=:accno")
	List<Transaction> getTransactionByAccno(@RequestParam("ACCOUNT_ACCNO") int accno);

}
