package com.cg.banking.exception;

public class AccountMismatchException extends Exception{
	public  AccountMismatchException(String message)
	{
		super(message);
	}

}
