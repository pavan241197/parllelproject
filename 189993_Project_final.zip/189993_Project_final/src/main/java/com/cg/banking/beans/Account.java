package com.cg.banking.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@SequenceGenerator(name = "seq1",initialValue = 100,allocationSize = 1)
@Table(name = "BankAccount")
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "seq1")
	private int accno;
	private double initialbalance;
	private String accType;
	private String name;
	private String mobile;
	private String doorno;
	private String city;
	private String pincode;
	public double getInitialbalance() {
		return initialbalance;
	}
	public void setInitialbalance(double initialbalance) {
		this.initialbalance = initialbalance;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getDoorno() {
		return doorno;
	}
	public void setDoorno(String dno) {
		this.doorno = dno;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public int getAccno() {
		return accno;
	}
	
	
	
	
}
