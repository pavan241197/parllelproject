package com.cg.banking.service;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exception.AccountMismatchException;
import com.cg.banking.exception.AccountNotFound;
import com.cg.banking.exception.InvalidAmountException;

public interface BankService {

	List<Account> createAcccount(Account account);

	List<Account> getAllAccounts();

	List<Account> deposit(int accno, double amount) throws InvalidAmountException, AccountNotFound;

	List<Account> withdraw(int accno, double amount) throws InvalidAmountException, AccountNotFound;

	List<Account> fundsTransfer(int accno1, int accno2, double amount)
			throws AccountMismatchException, InvalidAmountException, AccountNotFound;

	List<Transaction> getAllTransactions();

	double getInitialBalance(int accno) throws AccountNotFound;

	List<Transaction> getTransactionByAccno(int accno);

	Account getAccountByNo(int accno) throws AccountNotFound;

}
