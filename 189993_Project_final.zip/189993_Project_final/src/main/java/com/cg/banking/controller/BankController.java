package com.cg.banking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exception.AccountMismatchException;
import com.cg.banking.exception.AccountNotFound;
import com.cg.banking.exception.InvalidAmountException;
import com.cg.banking.service.BankService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class BankController {
	@Autowired
	private BankService bankService;
	
	@PostMapping("/create")
	public List<Account> addAccount(@RequestBody Account account) {
		return bankService.createAcccount(account);
	}
	@GetMapping("/accounts")
	public  List<Account> getAllAccounts()
	{
		return bankService.getAllAccounts();
	}
	@GetMapping("/get1/{accno}")
	public Account getAccountByNo(@PathVariable int accno) throws AccountNotFound {
		return bankService.getAccountByNo(accno);
	}
	
	@GetMapping("/accounts/deposit/{accno}/{amount}")
	public List<Account>  deposit(@PathVariable int accno,@PathVariable double amount) throws InvalidAmountException, AccountNotFound
	{
	
		return bankService.deposit(accno,amount);
	}
	@GetMapping("/accounts/withdraw/{accno}/{amount}")
	public List<Account>  withdraw(@PathVariable int accno,@PathVariable double amount) throws InvalidAmountException, AccountNotFound
	{
		
		return bankService.withdraw(accno,amount);
	}
	@GetMapping("/accounts/transfer/{accno1}/{accno2}/{amount}")
	public List<Account> fundsTransfer(@PathVariable int accno1,@PathVariable int accno2, @PathVariable double amount) throws AccountMismatchException, InvalidAmountException, AccountNotFound
	{
		
		return bankService.fundsTransfer(accno1,accno2,amount);
	}
	@GetMapping("/transactions")
	public List<Transaction> getAllTransactions()
	{
		return bankService.getAllTransactions();
		
	}
	@GetMapping("/initialbalance")
	public double getBalance(@RequestParam int accno) throws AccountNotFound
	{
		return bankService.getInitialBalance(accno);
	}
	@GetMapping("/get/{accno}")
	public List<Transaction> getTransactionByAccno(@PathVariable int accno) throws AccountNotFound
	{
		return bankService.getTransactionByAccno(accno);
		
	}
	
}
