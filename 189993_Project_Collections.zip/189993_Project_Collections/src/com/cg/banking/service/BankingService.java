package com.cg.banking.service;

import java.util.List;

import com.cg.banking.bean.Account;
import com.cg.banking.bean.Transaction;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficeintBalanceException;

interface BankingService {
	
	void CreateAccount(Account account);

	void Depositmoney(double amount, Integer accno) throws AccountNotFoundException;

	void Checkbalance(Integer accno)throws AccountNotFoundException;

	void Fundstransfer(Integer accno1, Integer accno2, double amount) throws AccountNotFoundException, InsufficeintBalanceException ;

	void Withdrawmoney(double amount, Integer accno)throws AccountNotFoundException, InsufficeintBalanceException;
	
	List<Transaction>  printTransactions(Integer accno) throws AccountNotFoundException ;

}
