package com.cg.banking.service;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.banking.bean.Account;
import com.cg.banking.bean.Customer;
import com.cg.banking.bean.Transaction;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficeintBalanceException;

public class BankingServiceImpl implements BankingService {
	Customer customer = new Customer();
	Account account = new Account();
	Scanner sc = new Scanner(System.in);
	Map<Integer, Account> acc = new HashMap<Integer, Account>();

	@Override
	public void CreateAccount(Account account) {
		acc.put(account.getAccountnumber(), account);
		System.out.println(acc);
	}

	@Override
	public void Depositmoney(double amount, Integer accno) throws AccountNotFoundException {
		double currentbalance = 0;
		if (acc.containsKey(accno)) {
			currentbalance += acc.get(accno).getStartingbalance() + amount;
			acc.get(accno).setStartingbalance(currentbalance);
			acc.get(accno).getList().add(new Transaction("CR", "Deposit", amount));
			System.out.println("deposit done sucessfully...");
		} else {
			System.out.println("account not found...");
		}
	}

	@Override
	public void Checkbalance(Integer accno) throws AccountNotFoundException {
		if (acc.containsKey(accno)) {
			System.out.println("balance in account=" + acc.get(accno).getStartingbalance());
		} else {
			System.out.println("account not found");
		}
	}

	@Override
	public void Withdrawmoney(double amount, Integer accno) throws InsufficeintBalanceException {
		double currentbalance = 0;
		if (acc.containsKey(accno)) {
			currentbalance += acc.get(accno).getStartingbalance() - amount;
			acc.get(accno).setStartingbalance(currentbalance);
			acc.get(accno).getList().add(new Transaction("DR", "Withdraw", amount));
			System.out.println("withdrawl done sucessfully...");
		} else {
			System.out.println("Insufficient funds...");
		}
	}

	@Override
	public void Fundstransfer(Integer accno1, Integer accno2, double amount) throws InsufficeintBalanceException {
		double receiver;
		double sender;
		if (accno1.equals(accno2)) {
			System.out.println("accs are same");
		} else {
			receiver = acc.get(accno2).getStartingbalance();
			sender = acc.get(accno1).getStartingbalance();
			if (amount > sender) {
				System.out.println("Insufficient funds so unable to transfer");
			} else {
				receiver = acc.get(accno2).getStartingbalance() + amount;
				
				sender = acc.get(accno1).getStartingbalance() - amount;
				acc.get(accno1).setStartingbalance(sender);
				acc.get(accno1).getList().add(new Transaction("DR", "Fund transfer", amount));
				acc.get(accno2).setStartingbalance(receiver);
				acc.get(accno2).getList().add(new Transaction("CR", "Fund transfer", amount));
				System.out.println("fund transfered done successfully....");
			}
		}
	}

	@Override
	public List<Transaction> printTransactions(Integer accno) throws AccountNotFoundException {
		if (acc.containsKey(accno)) {
			return acc.get(accno).getList();
		} else {
			System.out.println("Insufficient funds...");
			return null;
		}

	}

}
