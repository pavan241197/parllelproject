package com.cg.banking.bean;

import java.util.ArrayList;
import java.util.List;

public class Account {

	private String accounttype;
	static int accountnumber = 100;
	private Customer customer;
	private double startingbalance = 0;
	private List<Transaction> list = new ArrayList<>();

	public Account() {
		super();

		setAccountnumber(accountnumber);
		setAccounttype(accounttype);
		setCustomer(customer);
		setStartingbalance(startingbalance);

	}

	public String getAccounttype() {
		return accounttype;
	}

	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}

	public static int getAccountnumber() {
		return accountnumber++;
	}

	public static void setAccountnumber(int accountnumber) {
		Account.accountnumber = accountnumber;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public double getStartingbalance() {
		return startingbalance;
	}

	public void setStartingbalance(double startingbalance) {
		this.startingbalance = startingbalance;
	}

	public List<Transaction> getList() {
		return list;
	}

	public void setList(List<Transaction> list) {
		this.list = list;
	}

	@Override
	public String toString() {
		return "Account [accounttype=" + accounttype + ", customer=" + customer + ", startingbalance=" + startingbalance
				+ "]";
	}

}
