package com.cg.banking.exceptions;

public class InsufficeintBalanceException extends Exception {

	public InsufficeintBalanceException(String m) {
		super(m);
	}

}
