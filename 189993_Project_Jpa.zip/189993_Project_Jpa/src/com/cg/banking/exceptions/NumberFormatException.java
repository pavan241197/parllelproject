package com.cg.banking.exceptions;

public class NumberFormatException extends Exception{
	public NumberFormatException(String string)
	{
		System.err.println("Inputmismatch");
	}

}
