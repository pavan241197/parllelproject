package com.cg.banking.exceptions;

public class InsufficientBalanceException extends Exception
{

	public InsufficientBalanceException(Integer accno, String string) {
		super(accno+" "+string);
		System.err.println(accno+" "+string);
	}

}
