package com.cg.banking.exceptions;

public class InvalidQueryException extends Exception {
	public InvalidQueryException(String message)
	{
		System.err.println(message);
	}

}
