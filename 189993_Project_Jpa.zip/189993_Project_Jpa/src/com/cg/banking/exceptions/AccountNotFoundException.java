package com.cg.banking.exceptions;

import java.util.Scanner;

public class AccountNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AccountNotFoundException(int accno, String string) {
		super(accno + " " + string);
		Scanner sc = new Scanner(System.in);
		System.err.println(accno + " " + string);
		sc.nextLine();

	}
	public AccountNotFoundException()
	{
		super();
	}
	public AccountNotFoundException(String string) {
		System.err.println(string);
	}

}
