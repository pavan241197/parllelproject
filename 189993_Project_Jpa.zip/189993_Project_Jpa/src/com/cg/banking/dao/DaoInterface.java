package com.cg.banking.dao;

import java.sql.Date;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientBalanceException;
import com.cg.banking.exceptions.InvalidQueryException;

public interface DaoInterface {
	void createAccount(Account account);

	void deposit(int accno, double balance) throws InsufficientBalanceException, AccountNotFoundException;

	void withdraw(int accno, double balance) throws InsufficientBalanceException, AccountNotFoundException;

	void query();

	void fundstransfer(int accno11, int accno12, double currbalance1, double currentbalance2)
			throws InsufficientBalanceException, AccountNotFoundException;

	String calcQuery(String query) throws AccountNotFoundException, InvalidQueryException;

	void addTransaction(Transaction transaction, int accno, Date date);

	void delete(int accno11);
}
