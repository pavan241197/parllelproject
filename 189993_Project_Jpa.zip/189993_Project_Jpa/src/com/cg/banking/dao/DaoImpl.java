package com.cg.banking.dao;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientBalanceException;
import com.cg.banking.exceptions.InvalidQueryException;

public class DaoImpl implements DaoInterface {
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em = factory.createEntityManager();
	Scanner sc = new Scanner(System.in);

	@Override
	public void createAccount(Account account) {
		em.getTransaction().begin();
		em.persist(account);
		em.getTransaction().commit();

	}

	@Override
	public void deposit(int accountno, double amount) throws InsufficientBalanceException, AccountNotFoundException {
		double balance = amount;
		TypedQuery<Account> query = em.createQuery("from Account where accno=:acno", Account.class);
		query.setParameter("acno", accountno);
		Account a = query.getSingleResult();
		if (balance > 0) {
			double currentbalance = a.getInitialbalance() + balance;
			em.getTransaction().begin();
			a.setInitialbalance(currentbalance);
			em.getTransaction().commit();
		} else {
			throw new InsufficientBalanceException(accountno, "Enter Valid Amount");
		}

	}

	@Override
	public void withdraw(int accountno, double amount) {

		TypedQuery<Account> query = em.createQuery("from Account where accno=:acno", Account.class);
		query.setParameter("acno", accountno);
		Account a = query.getSingleResult();
		if (amount > 0) {
			double currentbalance = a.getInitialbalance() - amount;
			em.getTransaction().begin();
			a.setInitialbalance(currentbalance);
			em.getTransaction().commit();
		} else {
			try {
				throw new InsufficientBalanceException(accountno, "Enter Valid Amount");
			} catch (InsufficientBalanceException e) {
				e.printStackTrace();
			}
		}

	}

	@Override
	public void query() {
		System.out.println("enter Query");
		String query = sc.nextLine();
		System.out.println("enter Tablename");
		String tablename = sc.nextLine();
		if (tablename.equals("Account")) {
			Query q1 = em.createQuery(query);
			List<Account> list = q1.getResultList();
			for (Account ac : list) {
				System.out.println(ac);
			}
		} else if (tablename.equals("Customer")) {
			Query q1 = em.createQuery(query);
			List<Customer> list = q1.getResultList();
			for (Customer ac : list) {
				System.out.println(ac);
			}
		} else if (tablename.equals("Transaction")) {
			Query q1 = em.createQuery(query);
			List<Transaction> list = q1.getResultList();
			for (Transaction ac : list) {
				System.out.println(ac);
			}
		}
	}

	@Override
	public String calcQuery(String query) throws AccountNotFoundException {
		String result = null;
		Query query2 = em.createQuery(query);
		try{
		result = String.valueOf(query2.getSingleResult());
		}
		catch(NoResultException e){
			try {
				throw new InvalidQueryException("No entity Found");
			} catch (InvalidQueryException e1) {
				
			}
		}
		return result;
	}

	@Override

	public void fundstransfer(int accno11, int accno12, double currbalance1, double currentbalance2) {
		TypedQuery<Account> query = em.createQuery("from Account where accno=:p", Account.class);
		query.setParameter("p", accno11);
		Account account = query.getSingleResult();
		TypedQuery<Account> query2 = em.createQuery("from Account where accno=:g", Account.class);
		query2.setParameter("g", accno12);
		Account account1 = query2.getSingleResult();
		em.getTransaction().begin();
		account.setInitialbalance(currbalance1);
		account1.setInitialbalance(currentbalance2);
		em.getTransaction().commit();

	}

	@Override
	public void addTransaction(Transaction transaction, int accno1, Date date) {
		TypedQuery<Account> acc = em.createQuery("from Account where accno=:accno", Account.class);
		acc.setParameter("accno", accno1);
		Account account = acc.getSingleResult();
		Transaction trans = new Transaction();
		em.getTransaction().begin();
		trans.setAmount(transaction.getAmount());
		trans.setDescription(transaction.getDescription());
		trans.setType(transaction.getType());
		trans.setDate1(date);
		// trans.setAccount(account);
		em.persist(trans);
		em.getTransaction().commit();

	}

	@Override
	public void delete(int accno11) {
		String res = "delete from Account where accno=" + accno11;
		em.getTransaction().begin();
		int count = em.createQuery(res).executeUpdate();
		if (count > 0) {
			System.out.println("Deleted Successfully");
		}
		em.getTransaction().commit();

	}

}
