package com.cg.banking.beans;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name = "acc", initialValue = 1, allocationSize = 1)
public class Account implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(generator = "acc", strategy = GenerationType.SEQUENCE)
	private int accno;
	private double initialbalance;
	private String accType;
	@OneToOne(cascade = CascadeType.ALL)
	private Customer customer;
	
	public int getAccno() {
		return accno;
	}

	public void setAccno(int accno) {
		this.accno = accno;
	}

	public double getInitialbalance() {
		return initialbalance;
	}

	public void setInitialbalance(double initialbalance) {
		this.initialbalance = initialbalance;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Account [accno=" + accno + ", initialbalance=" + initialbalance + ", accType=" + accType + ", customer="
				+ customer + "]";
	}

}
