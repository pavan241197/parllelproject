package com.cg.banking.service;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountMismatchException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientBalanceException;
import com.cg.banking.exceptions.InvalidQueryException;

public interface BankingService {

	void createAccount(Account account);

	void deposit() throws InsufficientBalanceException, AccountNotFoundException, NumberFormatException, InvalidQueryException;

	void withdraw() throws InsufficientBalanceException, AccountNotFoundException, NumberFormatException, InvalidQueryException;

	void fundsTransfer() throws InsufficientBalanceException, AccountNotFoundException, AccountMismatchException, NumberFormatException, InvalidQueryException;

	void query();
	public void showbalance() throws NumberFormatException, AccountNotFoundException;

}
