package com.cg.banking.ui;

import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientBalanceException;
import com.cg.banking.exceptions.InvalidQueryException;
import com.cg.banking.service.BankingServiceImpl;

public class Bank {
	static Scanner sc = new Scanner(System.in);

	private static String input(String string) {
		String message = string;
		System.out.println(message);
		return sc.next();
	}

	private static Account createCustomer() {
		Account account = new Account();
		Customer customer = new Customer();
		account.setAccType(input("Enter Account Type"));
		customer.setName(input("enter Name"));
		customer.setMobile(input("enter Mobile no"));
		customer.setCity(input("enter city"));
		customer.setDno(input("enter door no"));
		customer.setPincode(input("enter pincode"));

		account.setCustomer(customer);
		return account;
	}

	public static void main(String[] args) throws InsufficientBalanceException, InvalidQueryException {
		BankingServiceImpl impl = new BankingServiceImpl();
		String choice = null;
		do {
			System.out.println("welcome to paypa Bank");
			System.out.println("1 :Create Account");
			System.out.println("2 :Deposit");
			System.out.println("3 :Show Balance");
			System.out.println("4 :with draw");
			System.out.println("5 :Funds Transfer");
			// System.out.println("6 :Print Transactions");
			// System.out.println("5: Delete");
			System.out.println("6 : Query");
			System.out.println("Enter Choice: ");
			choice = sc.next();
			// sc.nextLine();

			switch (choice) {
			case "1":
				impl.createAccount(createCustomer());
				System.out.println("Account created Successfully");
				break;
			case "2":

				try {
					impl.deposit();
				} catch (NumberFormatException | InsufficientBalanceException | AccountNotFoundException
						| InvalidQueryException e1) {

				}

				break;
			case "3":
				try {
					impl.showbalance();
				} catch (AccountNotFoundException | NumberFormatException e) {
				}
				break;

			case "4":
				try {
					impl.withdraw();
				} catch (AccountNotFoundException | InsufficientBalanceException | NumberFormatException
						| InvalidQueryException e) {
				}
				break;
			case "5":

				try {
					impl.fundsTransfer();
				} catch (NumberFormatException | InsufficientBalanceException | AccountNotFoundException
						| InvalidQueryException e1) {

				}

				break;

			case "6":
				impl.query();
				break;

			}
		} while (choice.length() != 0);

	}

}
